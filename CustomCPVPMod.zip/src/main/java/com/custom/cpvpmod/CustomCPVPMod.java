package com.custom.cpvpmod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

@Mod(modid = "customcpvpmod", name = "Custom CPVP Mod", version = "2.2")
public class CustomCPVPMod {

    public static KeyBinding menuKey;
    public static boolean safeWalkToggle = false;
    public static boolean scaffoldToggle = false;
    public static boolean killAuraToggle = false;
    public static boolean autoTotemToggle = false;
    public static boolean autoCrystalToggle = false;

    private long lastAttackTime = 0;
    private long attackDelay = 5000;
    private int scaffoldTickCount = 0;
    private long lastCrystalTime = 0;
    private long crystalDelay = 5000;

    @EventHandler
    public void init(FMLInitializationEvent event) {
        menuKey = new KeyBinding("CPVP Custom Menu", Keyboard.KEY_V, "Custom Mod");
        ClientRegistry.registerKeyBinding(menuKey);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        if (menuKey.isPressed()) {
            Minecraft.getMinecraft().displayGuiScreen(new CustomModGui());
        }
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null || mc.world == null) return;

        if (autoTotemToggle) {
            if (mc.player.getHeldItemOffhand().getItem() != Items.TOTEM_OF_UNDYING) {
                int totemSlot = findItemSlot(Items.TOTEM_OF_UNDYING);
                if (totemSlot != -1) {
                    mc.playerController.windowClick(mc.player.inventoryContainer.windowId, totemSlot, 0, ClickType.PICKUP, mc.player);
                    mc.playerController.windowClick(mc.player.inventoryContainer.windowId, 45, 0, ClickType.PICKUP, mc.player);
                    mc.playerController.windowClick(mc.player.inventoryContainer.windowId, totemSlot, 0, ClickType.PICKUP, mc.player);
                }
            }
        }

        if (autoCrystalToggle) {
            if (System.currentTimeMillis() - lastCrystalTime >= crystalDelay) {
                double reach = 4.0;
                EntityPlayer target = null;
                for (Entity entity : mc.world.loadedEntityList) {
                    if (entity instanceof EntityPlayer && entity != mc.player) {
                        if (mc.player.getDistanceSq(entity) <= reach * reach) {
                            target = (EntityPlayer) entity;
                            break;
                        }
                    }
                }

                if (target != null) {
                    BlockPos targetPos = new BlockPos(target.posX, target.posY - 1.0, target.posZ);
                    if (mc.world.getBlockState(targetPos).getBlock() == Blocks.OBSIDIAN || mc.world.getBlockState(targetPos).getBlock() == Blocks.AIR) {
                        int obsidianSlot = findBlockSlot(Blocks.OBSIDIAN);
                        int crystalSlot = findItemSlot(Items.END_CRYSTAL);

                        if (obsidianSlot != -1 && crystalSlot != -1) {
                            int oldSlot = mc.player.inventory.currentItem;
                            if (obsidianSlot < 9) {
                                mc.player.inventory.currentItem = obsidianSlot;
                            } else {
                                mc.playerController.windowClick(mc.player.inventoryContainer.windowId, obsidianSlot, 0, ClickType.PICKUP, mc.player);
                                mc.playerController.windowClick(mc.player.inventoryContainer.windowId, 36, 0, ClickType.PICKUP, mc.player);
                                mc.playerController.windowClick(mc.player.inventoryContainer.windowId, obsidianSlot, 0, ClickType.PICKUP, mc.player);
                                mc.player.inventory.currentItem = 0;
                            }

                            if (mc.world.getBlockState(targetPos).getBlock() == Blocks.AIR) {
                                mc.playerController.processRightClickBlock(mc.player, mc.world, targetPos, net.minecraft.util.EnumFacing.UP, new Vec3d(0.5, 0.5, 0.5), EnumHand.MAIN_HAND);
                            }

                            if (crystalSlot < 9) {
                                mc.player.inventory.currentItem = crystalSlot;
                            } else {
                                mc.playerController.windowClick(mc.player.inventoryContainer.windowId, crystalSlot, 0, ClickType.PICKUP, mc.player);
                                mc.playerController.windowClick(mc.player.inventoryContainer.windowId, 37, 0, ClickType.PICKUP, mc.player);
                                mc.playerController.windowClick(mc.player.inventoryContainer.windowId, crystalSlot, 0, ClickType.PICKUP, mc.player);
                                mc.player.inventory.currentItem = 1;
                            }

                            mc.playerController.processRightClickBlock(mc.player, mc.world, targetPos, net.minecraft.util.EnumFacing.UP, new Vec3d(0.5, 0.5, 0.5), EnumHand.MAIN_HAND);

                            for (Entity entity : mc.world.loadedEntityList) {
                                if (entity instanceof EntityEnderCrystal && mc.player.getDistanceSq(entity) <= reach * reach) {
                                    mc.playerController.attackEntity(mc.player, entity);
                                    mc.player.swingArm(EnumHand.MAIN_HAND);
                                    break;
                                }
                            }

                            mc.player.inventory.currentItem = oldSlot;
                            lastCrystalTime = System.currentTimeMillis();
                            crystalDelay = 5000 + (long) (Math.random() * 2000);
                        }
                    }
                }
            }
        }

        if (scaffoldToggle) {
            if (mc.gameSettings.keyBindBack.isKeyDown()) {
                BlockPos belowPos = new BlockPos(mc.player.posX, mc.player.posY - 1.0, mc.player.posZ);
                if (mc.world.getBlockState(belowPos).getBlock() == Blocks.AIR) {
                    scaffoldTickCount++;
                    if (scaffoldTickCount % 2 == 0) {
                        mc.player.setSneaking(true);
                    } else {
                        mc.player.setSneaking(false);
                    }
                }
            } else {
                scaffoldTickCount = 0;
            }
        }

        if (killAuraToggle) {
            int nearbyPlayers = 0;
            EntityPlayer target = null;
            double reach = 3.0;

            for (Entity entity : mc.world.loadedEntityList) {
                if (entity instanceof EntityPlayer && entity != mc.player) {
                    if (mc.player.getDistanceSq(entity) <= reach * reach) {
                        nearbyPlayers++;
                        target = (EntityPlayer) entity;
                    }
                }
            }

            if (nearbyPlayers >= 2) {
                mc.player.setSneaking(true);
                return;
            }

            if (nearbyPlayers == 1 && target != null) {
                if (System.currentTimeMillis() - lastAttackTime >= attackDelay) {
                    mc.playerController.attackEntity(mc.player, target);
                    mc.player.swingArm(EnumHand.MAIN_HAND);
                    lastAttackTime = System.currentTimeMillis();
                    attackDelay = 5000 + (long) (Math.random() * 2000);
                }
            }
        }
    }

    private int findItemSlot(net.minecraft.item.Item item) {
        Minecraft mc = Minecraft.getMinecraft();
        for (int i = 0; i < 36; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack.getItem() == item) return i < 9 ? i + 36 : i;
        }
        return -1;
    }

    private int findBlockSlot(net.minecraft.block.Block block) {
        Minecraft mc = Minecraft.getMinecraft();
        for (int i = 0; i < 36; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (!stack.isEmpty() && stack.getItem() instanceof ItemBlock) {
                if (((ItemBlock) stack.getItem()).getBlock() == block) return i < 9 ? i + 36 : i;
            }
        }
        return -1;
    }

    public static class CustomModGui extends GuiScreen {
        @Override
        public void initGui() {
            this.buttonList.clear();
            int cx = this.width / 2 - 100;
            int cy = this.height / 2 - 75;
            this.buttonList.add(new GuiButton(1, cx, cy, 200, 20, "Auto SafeWalk: " + (safeWalkToggle ? "ON" : "OFF")));
            this.buttonList.add(new GuiButton(2, cx, cy + 25, 200, 20, "Smart Scaffold: " + (scaffoldToggle ? "ON" : "OFF")));
            this.buttonList.add(new GuiButton(3, cx, cy + 50, 200, 20, "Safe KillAura (5s): " + (killAuraToggle ? "ON" : "OFF")));
            this.buttonList.add(new GuiButton(4, cx, cy + 75, 200, 20, "Auto Totem: " + (autoTotemToggle ? "ON" : "OFF")));
            this.buttonList.add(new GuiButton(5, cx, cy + 100, 200, 20, "Auto Crystal (5s): " + (autoCrystalToggle ? "ON" : "OFF")));
        }

        @Override
        protected void actionPerformed(GuiButton button) throws IOException {
            if (button.id == 1) { safeWalkToggle = !safeWalkToggle; button.displayString = "Auto SafeWalk: " + (safeWalkToggle ? "ON" : "OFF"); }
            else if (button.id == 2) { scaffoldToggle = !scaffoldToggle; button.displayString = "Smart Scaffold: " + (scaffoldToggle ? "ON" : "OFF"); }
            else if (button.id == 3) { killAuraToggle = !killAuraToggle; button.displayString = "Safe KillAura (5s): " + (killAuraToggle ? "ON" : "OFF"); }
            else if (button.id == 4) { autoTotemToggle = !autoTotemToggle; button.displayString = "Auto Totem: " + (autoTotemToggle ? "ON" : "OFF"); }
            else if (button.id == 5) { autoCrystalToggle = !autoCrystalToggle; button.displayString = "Auto Crystal (5s): " + (autoCrystalToggle ? "ON" : "OFF"); }
        }

        @Override
        public boolean doesGuiPauseGame() { return false; }
    }
}
